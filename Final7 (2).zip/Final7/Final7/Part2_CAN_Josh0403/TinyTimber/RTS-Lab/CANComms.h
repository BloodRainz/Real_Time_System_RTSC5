#ifndef CANCOMMS_H
#define CANCOMMS_H

#define CAN_START 1
#define CAN_STOP 2
#define CAN_VOLUME 3
#define CAN_MUTE 4
#define CAN_TEMPO 5 
#define CAN_KEY '6'
#define CAN_STATE 7


#include "TinyTimber.h"
#include "canTinyTimber.h"

typedef struct {
    Object super;
	int state;
	int received_value;
    int received_value_length;
	int Rxenterd;
    int stateMSG;
} CANComms;

#define initCANComms() {initObject(), 0, 0, 0, 0}

extern CANComms canComms; 
char transmit_buf[8];
int getCANState(CANComms*, int);

void CANReceive(CANComms*, CANMsg received_msg);

int debug_value(CANComms*, uchar received_msg);
int debug_value2(CANComms*, uchar received_msg[8]);
int debug_value_length (CANComms*, uchar received_msg);

int debug_value2_length (CANComms*, uchar received_msg);

void getCanMSg(CANComms*, int);

#endif